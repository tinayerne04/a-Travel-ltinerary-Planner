﻿import java.io.*;
import java.util.*;

class TravelPlanner {
    static Scanner scanner = new Scanner(System.in);
    static List<Destination> destinations = new ArrayList<>();
    static double totalBudget = 0.0;

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- Travel Itinerary Planner ---");
            System.out.println("1. Add Destination");
            System.out.println("2. View Itinerary");
            System.out.println("3. Show Maps");
            System.out.println("4. Show Weather Info");
            System.out.println("5. Calculate Total Budget");
            System.out.println("6. Export Itinerary to File");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addDestination();
                    break;
                case 2:
                    viewItinerary();
                    break;
                case 3:
                    showMaps();
                    break;
                case 4:
                    showWeather();
                    break;
                case 5:
                    calculateBudget();
                    break;
                case 6:
                    exportItineraryToFile();
                    break;
                case 7:
                    exit = true;
                    System.out.println("Thank you for using the Travel Itinerary Planner!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Add a new destination with preferences
    private static void addDestination() {
        System.out.print("Enter destination name: ");
        scanner.nextLine();  // Consume newline
        String destinationName = scanner.nextLine();
        
        System.out.print("Enter travel dates (e.g., 20th Dec - 25th Dec): ");
        String dates = scanner.nextLine();
        
        System.out.print("Enter preferred activities (comma-separated): ");
        String activities = scanner.nextLine();
        
        System.out.print("Enter estimated accommodation cost per day: ");
        double accommodationCost = scanner.nextDouble();
        
        System.out.print("Enter transport cost to the destination: ");
        double transportCost = scanner.nextDouble();

        System.out.print("Enter activity budget: ");
        double activityCost = scanner.nextDouble();

        Destination destination = new Destination(destinationName, dates, activities, accommodationCost, transportCost, activityCost);
        destinations.add(destination);
        totalBudget += (accommodationCost + transportCost + activityCost);
        System.out.println("Destination added successfully!");
    }

    // View the full itinerary
    private static void viewItinerary() {
        if (destinations.isEmpty()) {
            System.out.println("No destinations in the itinerary.");
        } else {
            System.out.println("\n--- Your Itinerary ---");
            for (Destination destination : destinations) {
                System.out.println(destination);
            }
        }
    }

    // Simulated map feature (can integrate with actual map API in real-world apps)
    private static void showMaps() {
        System.out.println("\n--- Maps (Simulated) ---");
        if (destinations.isEmpty()) {
            System.out.println("No destinations to show on the map.");
        } else {
            for (Destination destination : destinations) {
                System.out.println("Showing map for: " + destination.getName() + " [***Map***]");
            }
        }
    }

    // Simulated weather feature (replace with API for real-world apps)
    private static void showWeather() {
        System.out.println("\n--- Weather Information (Simulated) ---");
        if (destinations.isEmpty()) {
            System.out.println("No destinations available for weather information.");
        } else {
            for (Destination destination : destinations) {
                System.out.println("Weather at " + destination.getName() + ": Sunny, 25°C");
            }
        }
    }

    // Calculate the total budget
    private static void calculateBudget() {
        System.out.println("\n--- Budget Calculation ---");
        System.out.println("Total estimated budget: $" + totalBudget);
    }

    // Export itinerary to a text file
    private static void exportItineraryToFile() {
        try (FileWriter writer = new FileWriter("itinerary.txt")) {
            writer.write("--- Travel Itinerary ---\n");
            for (Destination destination : destinations) {
                writer.write(destination.toString() + "\n");
            }
            writer.write("Total Budget: $" + totalBudget + "\n");
            System.out.println("Itinerary exported to 'itinerary.txt' successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while exporting the itinerary.");
        }
    }
}

class Destination {
    private String name;
    private String travelDates;
    private String activities;
    private double accommodationCost;
    private double transportCost;
    private double activityCost;

    public Destination(String name, String travelDates, String activities, double accommodationCost, double transportCost, double activityCost) {
        this.name = name;
        this.travelDates = travelDates;
        this.activities = activities;
        this.accommodationCost = accommodationCost;
        this.transportCost = transportCost;
        this.activityCost = activityCost;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Destination: " + name + "\n" +
               "Dates: " + travelDates + "\n" +
               "Activities: " + activities + "\n" +
               "Accommodation Cost: $" + accommodationCost + " per day\n" +
               "Transport Cost: $" + transportCost + "\n" +
               "Activity Cost: $" + activityCost + "\n";
    }
}
